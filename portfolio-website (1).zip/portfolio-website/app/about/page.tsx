import About from '../components/About'

export default function AboutPage() {
  return (
    <div className="bg-gray-100">
      <About />
    </div>
  )
}

