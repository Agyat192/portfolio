'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import AnimatedSectionHeader from '../components/AnimatedSectionHeader'

export default function BlogPage() {
  return (
    <div className="bg-gray-100 py-12 min-h-screen">
      <div className="container mx-auto px-4">
        <AnimatedSectionHeader>Blog</AnimatedSectionHeader>
        <motion.div
          className="flex flex-col items-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="relative w-48 h-48 mb-8">
            <Image
              src="/placeholder.svg?height=192&width=192"
              alt="Blog"
              width={192}
              height={192}
              className="rounded-full object-cover"
            />
          </div>
          <p className="text-center text-lg mb-4">
            Exciting content is on its way!
          </p>
          <p className="text-center text-md text-gray-600">
            Check back soon for insightful articles on cybersecurity, ethical hacking, and the latest in tech.
          </p>
        </motion.div>
      </div>
    </div>
  )
}

