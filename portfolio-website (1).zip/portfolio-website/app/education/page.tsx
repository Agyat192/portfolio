import Education from '../components/Education'

export default function EducationPage() {
  return (
    <div className="bg-white">
      <Education />
    </div>
  )
}

