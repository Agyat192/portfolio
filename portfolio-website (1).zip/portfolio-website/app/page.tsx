import Home from './components/Home'

export default function Page() {
  return (
    <div className="bg-gray-100">
      <Home />
    </div>
  )
}

